import express from "express";
import { conn } from "./sequelize.js";

//Tabelas
import setorTabela from "./setorTabela.js";

const PORT = 3333;
const app = express();
app.use(express.json());

//Estabelecer conexão com o banco e sincronizar as tabelas
conn
  .sync()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server started on PORT: ${PORT}`);
    });
  })
  .catch((error) => {
    console.log(error);
  });

//**********************************************INÍCIO DAS ROTAS PARA SETORES**********************************************

app.get("/setores", async (req, res) => {
  try {
    const setores = await setorTabela.findAll();
    res.status(200).json(setores);
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Erro interno ao listar setores" });
  }
});

app.post("/setores", async (req, res) => {
  try {
    const { nome } = req.body;

    const novoSetor = await setorTabela.create({
       nome: nome, 
      });
    res.status(201).json(novoSetor);

  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Não foi possível salvar o setor." });
  }
});

app.delete("/setores/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const deletado = await setorTabela.destroy({
      where: { id }
    });

    if (!deletado) {
    return  res.status(404).json({ error: "Setor não encontrado." });
    }

    res.status(204).send();

  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Não foi possível excluir o setor." });
  }
});

//**********************************************FIM DAS ROTAS PARA SETORES**********************************************

//ROTA 404
app.use((req, res) => {
  res.status(404).json({ message: "Rota não encontrada" });
});



